#ifndef KVM__VERSION_H
#define KVM__VERSION_H

int kvm_cmd_version(int argc, const char **argv, const char *prefix);

#endif
