#ifndef KVM__SANDBOX_H
#define KVM__SANDBOX_H

int kvm_cmd_sandbox(int argc, const char **argv, const char *prefix);

#endif
