#ifndef KVM__KVM_CONFIG_ARCH_H
#define KVM__KVM_CONFIG_ARCH_H

struct kvm_config_arch {
};

#endif /* KVM__MIPS_KVM_CONFIG_ARCH_H */
