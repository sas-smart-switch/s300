/*
 * version file for sntp
 */
#include <config.h>
const char * Version = "sntp 4.2.8p10-beta@1.3728-o Tue Mar 21 14:36:42 UTC 2017 (43)";
